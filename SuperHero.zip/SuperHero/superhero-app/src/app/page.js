"use client";

import { useEffect, useState } from "react";
import styles from "./page.module.css";

const ACCESS_TOKEN = "4995282617154105";
const BASE_URL = `https://superheroapi.com/api.php/${ACCESS_TOKEN}/`;

export default function Home() {
  const [heroes, setHeroes] = useState([]);

  const fetchHero = async (id) => {
    try {
      const response = await fetch(`${BASE_URL}${id}`);
      const data = await response.json();
      return data;
    } catch (error) {
      console.error("Erro ao buscar herói:", error);
      return null;
    }
  };

  useEffect(() => {
    const heroIds = [200, 465]; // IDs dos heróis
    const fetchHeroes = async () => {
      const heroData = await Promise.all(heroIds.map((id) => fetchHero(id)));
      setHeroes(heroData.filter(Boolean));
    };

    fetchHeroes();
  }, []);

  return (
    <div className={styles.heroes}>
      {heroes.map((hero) => (
        <article key={hero.id} className={styles.card}>
          <img src={hero.image.url} alt={hero.name} className={styles.image} />
          <h1>{hero.name}</h1>
          <p>
            Intelligence:{" "}
            <span
              className={styles.bar}
              style={{
                width: `${hero.powerstats.intelligence}%`,
                backgroundColor: "#F9B32F",
              }}
            />
          </p>
          <p>
            Strength:{" "}
            <span
              className={styles.bar}
              style={{
                width: `${hero.powerstats.strength}%`,
                backgroundColor: "#FF7C6C",
              }}
            />
          </p>
        </article>
      ))}
    </div>
  );
}
